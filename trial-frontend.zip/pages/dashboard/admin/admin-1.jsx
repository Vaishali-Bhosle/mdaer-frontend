import Layout from "../layout";

const Dashboard = () => {
  return (
    <Layout>
      {/* Replace this section with dynamic content */}
      <h1 className="text-2xl font-bold">This is Admin-1</h1>
    </Layout>
  );
};

export default Dashboard;
